<?php
if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access this file directly");
}