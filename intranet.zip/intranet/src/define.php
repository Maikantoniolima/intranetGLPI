<?php

if (!defined('PLUGIN_INTRANET_WEBDIR')) {
    define('PLUGIN_INTRANET_WEBDIR', '/plugins/intranet');
}